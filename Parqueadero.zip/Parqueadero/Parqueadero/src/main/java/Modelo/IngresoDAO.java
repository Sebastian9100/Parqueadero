/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Servicios.DBConnection;
import java.sql.*;

/**
 *
 * @author estudiante
 */
public class IngresoDAO {
    public boolean verificarPlaca(String placa) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT * FROM ingreso WHERE placa = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, placa);
        ResultSet rs = ps.executeQuery();
        return rs.next(); // Devuelve true si encuentra la placa
    }

    public void registrarVehiculo(Vehiculo vehiculo) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "INSERT INTO ingreso (placa, tipo, modelo, valor) VALUES (?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, vehiculo.getPlaca());
        ps.setString(2, vehiculo.getTipo());
        ps.setInt(3, vehiculo.getModelo());
        ps.setInt(4, vehiculo.getValor());
        ps.executeUpdate();
    }
    
    // Otros métodos: limpiar registros, totalizar, etc.
}

