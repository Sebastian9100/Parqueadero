/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.IngresoDAO;
import Vista.Vista;

/**
 *
 * @author estudiante
 */
public class IngresoController {
    private IngresoDAO ingresoDAO;
    private Vista vista; // Tu clase de interfaz gráfica

    public IngresoController(IngresoDAO dao, Vista vista) {
        this.ingresoDAO = dao;
        this.vista = vista;

        // Asignar acciones a los botones
        this.vista.getBtnAgregar().addActionListener(e -> agregarVehiculo());
        this.vista.getBtnLimpiar().addActionListener(e -> limpiarFormulario());
        this.vista.getBtnReiniciar().addActionListener(e -> reiniciarRegistros());
        this.vista.getBtnTotalizar().addActionListener(e -> totalizarVehiculos());
    }

    private void agregarVehiculo() {
        // Verificar placa y añadir el vehículo si es válido
        // Cálculo del valor según el modelo
        // Mostrar mensaje de éxito o error
    }

    private void limpiarFormulario() {
        vista.limpiarCampos();
    }

    private void reiniciarRegistros() {
        // Llamar a ingresoDAO para eliminar todos los registros
    }

    private void totalizarVehiculos() {
        // Consultar la base de datos para obtener totales
    }
}