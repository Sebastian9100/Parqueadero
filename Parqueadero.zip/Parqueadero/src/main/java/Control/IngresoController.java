/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.IngresoDAO;
import Vista.VistaParqueadero;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author estudiante
 */
public class IngresoController implements ActionListener {
    private VistaParqueadero vista;
    private IngresoDAO ingresoDao;

    public IngresoController(VistaParqueadero vista, IngresoDAO ingresoDao) {
        this.vista = vista;
        this.ingresoDao = ingresoDao;
        
        // Agregar listeners a los botones
        this.vista.getBtnAgregar().addActionListener(this);
        this.vista.getBtnLimpiar().addActionListener(this);
        this.vista.getBtnReiniciar().addActionListener(this);
        this.vista.getBtnTotalizar().addActionListener(this);
        
        actualizarContadores();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBtnAgregar()) {
            agregarVehiculo();
        } else if (e.getSource() == vista.getBtnLimpiar()) {
            limpiarCampos();
        } else if (e.getSource() == vista.getBtnReiniciar()) {
            reiniciarDatos();
        } else if (e.getSource() == vista.getBtnTotalizar()) {
            totalizar();
        }
    }

    private void agregarVehiculo() {
        String placa = vista.getTxtPlaca().getText();
        String modeloStr = vista.getTxtModelo().getText();
        String fechaStr = vista.getTxtFecha().getText(); // Mantener como String
        String tipoVehiculo = (String) vista.getJComboBox().getSelectedItem();

        // Validar placa
        if (!validarPlaca(placa, tipoVehiculo)) {
            vista.mostrarMensajeError("Placa inválida.");
            return;
        }

        // Convertir modelo a int
        int modelo;

        try {
            modelo = Integer.parseInt(modeloStr);
        } catch (NumberFormatException ex) {
            vista.mostrarMensajeError("Modelo debe ser un número entero.");
            return;
        }

        // Agregar vehículo a la base de datos
        boolean agregado = ingresoDao.agregarVehiculo(placa, modelo, fechaStr, tipoVehiculo);
    
        if (agregado) {
            // Si se agregó correctamente, actualiza contadores
            actualizarContadores();
            vista.mostrarMensaje("Vehículo agregado con éxito.");
        } else {
            // Si no se agregó, muestra un mensaje de error
            vista.mostrarMensajeError("La placa ya existe en la base de datos.");
        }
    }
    
    private boolean validarPlaca(String placa, String tipoVehiculo) {
        if (tipoVehiculo.equals("Carro") && placa.length() == 6) {
            return true;
        } else if (tipoVehiculo.equals("Moto") && placa.length() == 5) {
            return true;
        }
        return false;
    }

    private void limpiarCampos() {
        vista.getTxtPlaca().setText("");
        vista.getTxtModelo().setText("");
        vista.getTxtFecha().setText("");
        vista.getJComboBox().setSelectedIndex(0);
        vista.getTxtResultado().setText("");
    }

    private void reiniciarDatos() {
        // Mostrar cuadro de diálogo de confirmación
        int respuesta = JOptionPane.showConfirmDialog(vista, 
            "¿Está seguro de que desea reiniciar la base de datos?", 
            "Confirmación", 
            JOptionPane.YES_NO_OPTION);
        
        // Verificar la respuesta del usuario
        if (respuesta == JOptionPane.YES_OPTION) {
            ingresoDao.reiniciarBaseDatos(); 
            actualizarContadores();
            vista.mostrarMensaje("La base de datos ha sido reiniciada.");
        } else {
            vista.mostrarMensaje("Operación cancelada.");
        }
    }

    private void totalizar() {
        String resultado = ingresoDao.calcularResultados();
        vista.getTxtResultado().setText(resultado);
    }

    private void actualizarContadores() {
        vista.getTxtMotos().setText(String.valueOf(ingresoDao.getCantidadMotos()));
        vista.getTxtCarros().setText(String.valueOf(ingresoDao.getCantidadCarros()));
    }
}