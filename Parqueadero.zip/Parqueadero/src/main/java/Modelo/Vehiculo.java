/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Date;
/**
 *
 * @author estudiante
 */
public class Vehiculo {
    private String placa;
    private int modelo;
    private Date fecha;
    private String tipo;

    public Vehiculo(String placa, int modelo, Date fecha, String tipo) {
        this.placa = placa;
        this.modelo = modelo;
        this.fecha = fecha;
        this.tipo = tipo;
    }

    public String getPlaca() {
        return placa;
    }

    public int getModelo() {
        return modelo;
    }

    public Date getFecha() {
        return fecha;
    }

    public String getTipo() {
        return tipo;
    }
}