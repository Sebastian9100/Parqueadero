/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;
import Servicios.DBConnection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Date; // Importar la clase Date
import java.sql.ResultSet;

/**
 *
 * @author Sebastian
 */
public class IngresoDAO {
    private ArrayList<Vehiculo> vehiculos;
    private DBConnection dbConnection;

    public IngresoDAO() {
        vehiculos = new ArrayList<>();
        dbConnection = new DBConnection();
        cargarVehiculosDesdeBD(); // Llamar al método para cargar los vehículos desde la base de datos
    }

    // Método para cargar los vehículos desde la base de datos
    private void cargarVehiculosDesdeBD() {
        try {
            String sql = "SELECT * FROM registro"; // Suponiendo que 'registro' tiene todas las columnas necesarias
            PreparedStatement statement = dbConnection.getConnection().prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String placa = resultSet.getString("placa");
                int modelo = resultSet.getInt("modelo");
                Date fecha = resultSet.getDate("fecha"); // Asegúrate de que la columna sea tipo Date en la base de datos
                String tipoVehiculo = resultSet.getString("tipo");

                // Crear un nuevo vehículo con los datos recuperados
                Vehiculo vehiculo = new Vehiculo(placa, modelo, fecha, tipoVehiculo);
                vehiculos.add(vehiculo); // Agregar el vehículo al ArrayList
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejar el error según sea necesario
        }
    }
    public boolean agregarVehiculo(String placa, int modelo, String fechaStr, String tipoVehiculo) {
        // Convertir fechaStr a Date
        Date fecha = Date.valueOf(fechaStr); // Cambiar aquí a Date

        // Verificar si el vehículo ya existe en la base de datos
        if (vehiculoYaExiste(placa)) {
            return false; // Si existe, retorna false
        }

        // Agregar el vehículo al ArrayList
        vehiculos.add(new Vehiculo(placa, modelo, fecha, tipoVehiculo));

        int valor = calcularValor(tipoVehiculo, modelo); // Llamar a un nuevo método para calcular el valor

        try {
            String sql = "INSERT INTO registro (placa, modelo, fecha, tipo, valor) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = dbConnection.getConnection().prepareStatement(sql);
            statement.setString(1, placa);
            statement.setInt(2, modelo);
            statement.setDate(3, fecha); // Agregar la fecha como Date
            statement.setString(4, tipoVehiculo);
            statement.setInt(5, valor); // Agregar el valor calculado

            int rowsAffected = statement.executeUpdate();
            System.out.println(rowsAffected + " fila(s) afectada(s) al agregar el vehículo."); // Agregado para depuración
        
            return true; // Retorna true si se agregó exitosamente

        } catch (SQLException e) {
            e.printStackTrace(); // Imprime el stack trace de la excepción
            return false; // Retorna false en caso de error
        }
    }

    // Método para verificar si el vehículo ya existe
    private boolean vehiculoYaExiste(String placa) {
        try {
            String sql = "SELECT COUNT(*) FROM registro WHERE placa = ?";
            PreparedStatement statement = dbConnection.getConnection().prepareStatement(sql);
            statement.setString(1, placa);
        
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0; // Retorna true si hay al menos un registro
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Imprime el stack trace de la excepción
        }
        return false; // Retorna false si ocurrió un error
    }

    private int calcularValor(String tipoVehiculo, int año) {
        if (tipoVehiculo.equals("Carro")) {
            return (año < 2012) ? 2000 : 2500;
        } else if (tipoVehiculo.equals("Moto")) {
            return (año < 2012) ? 1000 : 1200;
        }
        return 0; // Valor por defecto si el tipo no es válido
    }

    public boolean existePlaca(String placa) {
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getPlaca().equals(placa)) {
                return true;
            }
        }
        return false;
    }

    public void reiniciarBaseDatos() {
        vehiculos.clear();
        
        try {
            String sql = "DELETE FROM registro";
            PreparedStatement statement = dbConnection.getConnection().prepareStatement(sql);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Manejar la excepción según tu lógica de error
        }
    }

    public int getCantidadMotos() {
        int count = 0;
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getTipo().equals("Moto")) {
                count++;
            }
        }
        return count;
    }

    public int getCantidadCarros() {
        int count = 0;
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getTipo().equals("Carro")) {
                count++;
            }
        }
        return count;
    }

    public String calcularResultados() {
        int totalCarros = getCantidadCarros();
        int totalMotos = getCantidadMotos();
        int dineroproducidoporcarros = 0;
        int dineroproducidopormotos = 0;

        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getTipo().equals("Carro")) {
                if (vehiculo.getModelo() < 2012) {
                    dineroproducidoporcarros += 2000;
                } else {
                    dineroproducidoporcarros += 2500;
                }
            } else if (vehiculo.getTipo().equals("Moto")) {
                if (vehiculo.getModelo() < 2012) {
                    dineroproducidopormotos += 1000;
                } else {
                    dineroproducidopormotos += 1200;
                }
            }
        }

        int totaldevehiculos = totalCarros + totalMotos;
        int totalrecaudado = dineroproducidoporcarros + dineroproducidopormotos;

        return "Resultado del día: el total de carros es " + totalCarros + 
               " con un valor de " + dineroproducidoporcarros + 
               ", el total de motos es " + totalMotos + 
               " para un valor de " + dineroproducidopormotos + 
               ", el total de vehículos fue " + totaldevehiculos + 
               " y el total recaudado " + totalrecaudado + ".";
    }
}