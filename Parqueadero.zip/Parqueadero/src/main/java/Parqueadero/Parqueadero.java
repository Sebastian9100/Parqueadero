/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Parqueadero;

import Modelo.IngresoDAO;
import Vista.VistaParqueadero;
import Control.IngresoController;
/**
 *
 * @author SEBASTIAN
 */
public class Parqueadero {
    public static void main(String[] args) {
        VistaParqueadero vista = new VistaParqueadero();
        vista.setVisible(true); // Asegúrate de que la ventana sea visible
        IngresoDAO ingresoDao = new IngresoDAO();
        IngresoController controlador = new IngresoController(vista, ingresoDao);
    }
}